<?php
$basePath = dirname(__FILE__);
$GLOBALS['current_page'] = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>About | Ovala Aguleri Festival</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;800&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css" />
    <style>
        /* About Page Specific Styles */
        .about-hero {
            background: linear-gradient(135deg, rgba(255, 159, 26, 0.1), rgba(255, 159, 26, 0.05));
            padding: 80px 60px;
            text-align: center;
            border-bottom: 2px solid var(--accent);
        }

        .about-hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: 3.5rem;
            color: var(--accent);
            margin-bottom: 20px;
            font-weight: 800;
        }

        .about-hero .subtitle {
            font-size: 1.3rem;
            color: var(--muted);
            max-width: 700px;
            margin: 0 auto;
            line-height: 1.6;
        }

        /* Significance Grid Section */
        .timeline-section {
            padding: 80px 60px;
            background: rgba(255, 159, 26, 0.02);
        }

        .timeline-section h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin-bottom: 50px;
            text-align: center;
        }

        .timeline-section h2 span {
            color: var(--accent);
        }

        .significance-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .significance-card {
            background: rgba(255, 159, 26, 0.08);
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid rgba(255, 159, 26, 0.2);
            transition: all 0.3s ease;
        }

        .significance-card:hover {
            background: rgba(255, 159, 26, 0.12);
            transform: translateY(-5px);
            border-color: var(--accent);
        }

        .sig-icon {
            font-size: 3rem;
            margin-bottom: 15px;
            display: block;
        }

        .significance-card h3 {
            color: var(--accent);
            font-size: 1.2rem;
            margin-bottom: 12px;
            font-weight: 600;
        }

        .significance-card p {
            color: var(--muted);
            line-height: 1.6;
            font-size: 0.9rem;
        }

        /* About Content Sections */
        .about-section {
            padding: 60px;
            border-bottom: 1px solid rgba(255, 159, 26, 0.2);
        }

        .about-section:nth-child(even) {
            background: rgba(255, 159, 26, 0.03);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .section-icon {
            font-size: 3rem;
            color: var(--accent);
        }

        .section-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.2rem;
            color: var(--text);
        }

        .section-header h2 span {
            color: var(--accent);
        }

        .about-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            align-items: start;
        }

        .about-content.single {
            grid-template-columns: 1fr;
        }

        .about-text h3 {
            color: var(--accent);
            font-size: 1.4rem;
            margin-bottom: 15px;
            margin-top: 20px;
        }

        .about-text h3:first-child {
            margin-top: 0;
        }

        .about-text p {
            color: var(--muted);
            line-height: 1.8;
            margin-bottom: 15px;
            text-align: justify;
        }

        .about-highlights {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .highlight-box {
            background: rgba(255, 159, 26, 0.1);
            padding: 25px;
            border-radius: 8px;
            border-left: 4px solid var(--accent);
        }

        .highlight-box h4 {
            color: var(--accent);
            margin-bottom: 10px;
            font-weight: 600;
        }

        .highlight-box p {
            color: var(--muted);
            font-size: 0.9rem;
            line-height: 1.6;
        }

        /* Gallery Grid */
        .about-gallery {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 30px;
        }

        .gallery-item {
            aspect-ratio: 1;
            background: rgba(255, 159, 26, 0.1);
            border-radius: 8px;
            overflow: hidden;
            border: 2px solid rgba(255, 159, 26, 0.2);
        }

        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Values Grid */
        .values-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            margin-top: 40px;
        }

        .value-card {
            background: rgba(255, 159, 26, 0.08);
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid rgba(255, 159, 26, 0.2);
            transition: all 0.3s ease;
        }

        .value-card:hover {
            background: rgba(255, 159, 26, 0.12);
            transform: translateY(-5px);
        }

        .value-card .icon {
            font-size: 2.5rem;
            color: var(--accent);
            margin-bottom: 15px;
        }

        .value-card h3 {
            color: var(--text);
            margin-bottom: 12px;
            font-weight: 600;
        }

        .value-card p {
            color: var(--muted);
            line-height: 1.6;
            font-size: 0.9rem;
        }

        /* Leadership Section */
        .leadership-section {
            padding: 80px 60px;
            background: transparent;
        }

        .leadership-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }

        .leadership-image {
            position: relative;
        }

        .image-placeholder {
            width: 100%;
            aspect-ratio: 1;
            background: rgba(255, 159, 26, 0.15);
            border-radius: 12px;
            overflow: hidden;
            border: 2px solid rgba(255, 159, 26, 0.2);
        }

        .image-placeholder img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .leadership-text h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin-bottom: 10px;
        }

        .leadership-text h2 span {
            color: var(--accent);
        }

        .leadership-text h3 {
            color: var(--accent);
            font-size: 1.3rem;
            margin-top: 25px;
            margin-bottom: 12px;
            font-weight: 600;
        }

        .leadership-text h3:first-of-type {
            margin-top: 0;
        }

        .leadership-text p {
            color: var(--muted);
            line-height: 1.8;
            margin-bottom: 15px;
            text-align: justify;
        }

        .leadership-text .btn {
            margin-top: 25px;
            display: inline-block;
        }

        /* Facts Section */
        .facts-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-top: 40px;
        }

        .fact-card {
            background: rgba(255, 159, 26, 0.1);
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            border: 2px solid var(--accent);
        }

        .fact-number {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            color: var(--accent);
            font-weight: 800;
            margin-bottom: 10px;
        }

        .fact-label {
            color: var(--muted);
            font-weight: 600;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .about-hero {
                padding: 50px 20px;
            }

            .about-hero h1 {
                font-size: 2.5rem;
            }

            .timeline-section {
                padding: 50px 20px;
            }

            .significance-grid {
                grid-template-columns: 1fr;
            }

            .about-section {
                padding: 40px 20px;
            }

            .about-content {
                grid-template-columns: 1fr;
                gap: 30px;
            }

            .values-grid {
                grid-template-columns: 1fr;
            }

            .leadership-content {
                grid-template-columns: 1fr;
                gap: 30px;
            }

            .about-gallery {
                grid-template-columns: 1fr;
            }

            .facts-grid {
                grid-template-columns: 1fr;
            }

            .section-header {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>

<body>
    <?php include 'nav.php'; ?>

    <!-- About Hero Section -->
    <section class="about-hero">
        <h1>A Legacy of <span>Cultural Pride</span></h1>
        <p class="subtitle">
            The Ovala Aguleri Festival represents more than a century of cultural excellence, ancestral connection, and
            community unity. It is a living testament to the enduring spirit of the Aguleri people and their commitment to
            preserving, celebrating, and sharing their rich Igbo heritage with the world.
        </p>
        <p class="subtitle">
            From the vibrant masquerades to the sacred ceremonies, from the rhythmic drumbeats to the colorful attire, every
            element of this festival embodies the wisdom, artistry, and values passed down through generations. It is a celebration
            not just of what we are, but of who we aspire to be as a unified community.
        </p>
    </section>

    <!-- Historical Timeline -->
    <section class="timeline-section">
        <h2>Cultural <span>Significance</span></h2>
        <div class="significance-grid">
            <div class="significance-card">
                <div class="sig-icon">🎭</div>
                <h3>Royal Heritage</h3>
                <p>From the reigning Obi to the cultural custodians, our festival celebrates the dignity and leadership that has guided Aguleri for centuries.</p>
            </div>
            <div class="significance-card">
                <div class="sig-icon">🌍</div>
                <h3>Community Unity</h3>
                <p>Aguleri sons and daughters gather from across Nigeria and the diaspora to reaffirm bonds of brotherhood, sisterhood, and shared identity.</p>
            </div>
            <div class="significance-card">
                <div class="sig-icon">🎨</div>
                <h3>Ancestral Connection</h3>
                <p>Through sacred ceremonies and traditional rites, we honor our forebears and maintain a spiritual link to those who came before us.</p>
            </div>
            <div class="significance-card">
                <div class="sig-icon">✨</div>
                <h3>Cultural Preservation</h3>
                <p>The festival stands as a living archive of Igbo traditions, artistic mastery, and wisdom that might otherwise be lost to modernization.</p>
            </div>
        </div>
    </section>

    <!-- Core Values Section -->
    <section class="about-section">
        <div class="section-header">
            <div class="section-icon">✨</div>
            <h2>Our Core <span>Values</span></h2>
        </div>
        <div class="values-grid">
            <div class="value-card">
                <div class="icon">🌍</div>
                <h3>Cultural Pride</h3>
                <p>
                    Celebrating and preserving the unique heritage, traditions, and identity of the Aguleri people
                    for present and future generations.
                </p>
            </div>
            <div class="value-card">
                <div class="icon">🤝</div>
                <h3>Community Unity</h3>
                <p>
                    Fostering bonds of brotherhood and sisterhood among Aguleri people, strengthening social cohesion
                    and collective identity.
                </p>
            </div>
            <div class="value-card">
                <div class="icon">🙏</div>
                <h3>Ancestral Veneration</h3>
                <p>
                    Honoring the memory and legacy of our forebears, acknowledging their sacrifices and wisdom that
                    shaped our present.
                </p>
            </div>
            <div class="value-card">
                <div class="icon">🎨</div>
                <h3>Artistic Excellence</h3>
                <p>
                    Showcasing the finest traditional and contemporary artistic expressions through music, dance,
                    and visual arts.
                </p>
            </div>
            <div class="value-card">
                <div class="icon">📚</div>
                <h3>Cultural Education</h3>
                <p>
                    Educating younger generations and visitors about Aguleri history, traditions, language, and values
                    through immersive experiences.
                </p>
            </div>
            <div class="value-card">
                <div class="icon">🌱</div>
                <h3>Sustainable Development</h3>
                <p>
                    Using the festival platform to drive socioeconomic development, create opportunities, and promote
                    environmental stewardship.
                </p>
            </div>
        </div>
    </section>
    <!-- Community Leadership Section -->
    <section class="about-section leadership-section">
        <div class="leadership-content">
            <div class="leadership-image">
                <div class="image-placeholder">
                    <img src="assets/community.png" alt="Community Leadership">
                </div>
            </div>
            <div class="leadership-text">
                <h2>Community <span>Leadership</span></h2>
                <h3>Guardians of Our Heritage</h3>
                <p>
                    The Ovala Aguleri Festival is guided by a dedicated council of traditional and community leaders committed
                    to preserving our cultural identity while embracing progress. Under the leadership of His Majesty Obi and
                    the collective wisdom of cultural custodians, the festival continues to grow stronger with each passing year.
                </p>

                <h3>Our Vision</h3>
                <p>
                    We envision the Ovala Aguleri Festival as a beacon of Igbo cultural pride, a model for sustainable cultural
                    preservation, and a platform that empowers our youth to take ownership of their heritage. By honoring our past
                    and embracing our present, we build a future where Aguleri culture thrives globally.
                </p>

                <h3>Our Mission</h3>
                <p>
                    To celebrate, preserve, and promote the rich cultural heritage of the Aguleri people through an annual festival
                    that brings together community members, strengthens social bonds, supports artisans and cultural practitioners,
                    and showcases Igbo traditions to a global audience.
                </p>

                <a href="contact.php" class="btn primary">Join Our Leadership</a>
            </div>
        </div>
    </section>



    <?php include 'footer.php'; ?>

    <script src="script.js"></script>
</body>

</html>