<?php
$basePath = dirname(__FILE__);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Ovala Aguleri Festival</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;800&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <?php
    $GLOBALS['current_page'] = basename($_SERVER['PHP_SELF']);
    include 'nav.php';
    ?>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-left">
            <div class="badge">📅 Dec 27, 2025 – Jan 5, 2026 · 126th Edition</div>

            <h1>
                Ovala<br>
                <span>Aguleri</span><br>
                Festival
            </h1>

            <em class="tagline">"Ovala Uwa Oruu"</em>

            <p>
                Experience the vibrant celebration of Igbo heritage through music,
                dance, masquerades, and the timeless traditions of the Aguleri people.
            </p>
        </div>

        <div class="hero-right">
            <div class="countdown-card">
                <h3>📅 126th Edition Countdown</h3>
                <p class="quote">"Ovala Uwa Oruu"</p>

                <div class="countdown">
                    <div><span id="days">00</span><small>DAYS</small></div>
                    <div><span id="hours">00</span><small>HOURS</small></div>
                    <div><span id="minutes">00</span><small>MINUTES</small></div>
                    <div><span id="seconds">00</span><small>SECONDS</small></div>
                </div>

                <p class="location">
                    📍 Dec 27, 2025 – Jan 5, 2026 · Aguleri, Nigeria
                </p>
            </div>
        </div>
        <div class="buttons">
            <a class="btn primary">Learn More →</a>
            <a class="btn outline">Contact Us</a>
        </div>
    </section>

    <!-- Heritage Section -->
    <section class="heritage" id="heritage">
        <div class="heritage-top">

            <div class="location">
                📍 Aguleri, Anambra State, Nigeria
            </div>

        </div>

        <div class="heritage-content">
            <h2>
                A Celebration of <span>Heritage</span>
            </h2>

            <p>
                The Ovala Aguleri Festival is an annual cultural celebration that brings
                together the sons and daughters of Aguleri to honor their ancestors,
                celebrate their rich heritage, and strengthen the bonds of community.
                For generations, this festival has been the heartbeat of Aguleri's
                cultural identity.
            </p>

            <a class="btn primary center">Discover Our Story</a>
        </div>
    </section>


    <!-- Highlights Section -->
    <section id="highlights">
        <h2 class="section-title">Festival <span>Highlights</span></h2>
        <div class="highlights-grid">
            <div class="highlight-card">
                <img src="assets/image1.jpg" alt="Cultural Performance">
                <div class="highlight-content">
                    <h3>Cultural Performance</h3>
                    <p>Experience breathtaking traditional dances and performances that showcase our rich heritage</p>
                </div>
            </div>
            <div class="highlight-card">
                <img src="assets/image2.jpg" alt="Royal Dance Ceremony">
                <div class="highlight-content">
                    <h3>Royal Dance Ceremony</h3>
                    <p>Witness the majestic royal dance ceremony featuring traditional attire and ancient rituals</p>
                </div>
            </div>
            <div class="highlight-card">
                <img src="assets/image3.jpg" alt="Art Gallery">
                <div class="highlight-content">
                    <h3>Art Gallery</h3>
                    <p>Explore stunning traditional art pieces and crafts from local artisans</p>
                </div>
            </div>
        </div>
        <div style="text-align: center; margin-top: 3rem;">
            <a href="#schedule" class="btn primary">View Full Schedule</a>
        </div>
    </section>


    <!-- News Section -->
    <section id="news" class="news">
        <div class="news-header">
            <div class="news-title-block">
                <div class="news-label">
                    <span class="news-icon">📰</span>
                    <span class="latest-text">Latest News</span>
                </div>
                <h2 class="section-title">Festival <span>News</span></h2>
            </div>
            <a href="#" class="btn primary">View All News</a>
        </div>
        <div class="news-grid">
            <div class="news-card">
                <img src="assets/festival1.jpg" alt="News 1">
                <div class="news-content">
                    <div class="news-meta">
                        <span class="news-category">Festival</span>
                        <span class="news-date">28 December, 2025</span>
                    </div>
                    <h3>2024 Festival Marks Record Attendance</h3>
                    <p>Over 50,000 visitors celebrated at this year's festival, making it the largest gathering in history</p>
                </div>
            </div>
            <div class="news-card">
                <img src="assets/festival2.jpg" alt="News 2">
                <div class="news-content">
                    <div class="news-meta">
                        <span class="news-category">News</span>
                        <span class="news-date">27 December, 2025</span>
                    </div>
                    <h3>New Cultural Center Opens in Aguleri</h3>
                    <p>The community welcomes a state-of-the-art cultural center dedicated to preserving our heritage</p>
                </div>
            </div>
            <div class="news-card">
                <img src="https://images.unsplash.com/photo-1511578314322-379afb476865?w=600" alt="News 3">
                <div class="news-content">
                    <div class="news-meta">
                        <span class="news-category">Youth</span>
                        <span class="news-date">26 December, 2025</span>
                    </div>
                    <h3>Youth Initiative Launches New Programs</h3>
                    <p>Exciting new programs aim to engage younger generations in cultural preservation</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Community Section -->
    <section class="community">
        <div class="community-content">
            <h2>Unite with <span>Community</span></h2>
            <p>Our festival brings together thousands of people from diverse backgrounds to celebrate unity, tradition, and the vibrant spirit of the Aguleri community. Join us in this incredible journey of cultural celebration.</p>

            <div class="community-stats">
                <div class="stat">
                    <div class="number">50K+</div>
                    <div class="label">Visitors</div>
                </div>
                <div class="stat">
                    <div class="number">100+</div>
                    <div class="label">Events</div>
                </div>
                <div class="stat">
                    <div class="number">30+</div>
                    <div class="label">Communities</div>
                </div>
            </div>

            <button class="btn primary community-btn">Join Us 👥</button>
        </div>
        <div class="community-image">
            <img src="assets/community1.jpg" alt="Community">
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <h2>Experience the Magic</h2>
        <p>Join us for the biggest cultural celebration in Aguleri. Connect with your heritage,<br> make memories that last a lifetime.</p>
        <div class="cta-buttons">
            <a href="#" class="btn outline">View Gallery</a>
            <a href="#" class="btn primary">Get In Touch</a>
        </div>
    </section>

    <?php include 'footer.php'; ?>
    <script src="script.js"></script>
</body>

</html>