// Initialize theme on page load
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('themeToggle');
  
  // Load saved theme preference or default to dark
  const savedTheme = localStorage.getItem('theme') || 'dark';
  if (savedTheme === 'dark') {
    document.body.classList.add('dark');
    if (toggle) toggle.textContent = '☀️';
  } else {
    document.body.classList.remove('dark');
    if (toggle) toggle.textContent = '🌙';
  }

  // Theme Toggle - Make sure button exists and is clickable
  if (toggle) {
    // Use capturing phase to ensure we catch the click
    toggle.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      document.body.classList.toggle('dark');
      toggle.textContent = document.body.classList.contains('dark') ? '☀️' : '🌙';
      localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
    }, false);
    
    // Also add mousedown as fallback
    toggle.addEventListener('mousedown', function(e) {
      e.preventDefault();
      e.stopPropagation();
    }, false);
  }

  // Countdown
  const targetDate = new Date('December 27, 2025 00:00:00').getTime();

  const updateCountdown = () => {
    const now = new Date().getTime();
    const diff = targetDate - now;

    const d = Math.floor(diff / (1000 * 60 * 60 * 24));
    const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const m = Math.floor((diff / (1000 * 60)) % 60);
    const s = Math.floor((diff / 1000) % 60);

    const daysEl = document.getElementById('days');
    const hoursEl = document.getElementById('hours');
    const minutesEl = document.getElementById('minutes');
    const secondsEl = document.getElementById('seconds');

    if (daysEl) daysEl.textContent = d.toString().padStart(2, '0');
    if (hoursEl) hoursEl.textContent = h.toString().padStart(2, '0');
    if (minutesEl) minutesEl.textContent = m.toString().padStart(2, '0');
    if (secondsEl) secondsEl.textContent = s.toString().padStart(2, '0');
  };

  // Update countdown immediately and then every second
  updateCountdown();
  setInterval(updateCountdown, 1000);

  // Header scroll effect
  window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    if (header) {
      if (window.scrollY > 20) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }
  });

  // FAQ Toggle
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const header = item.querySelector('.faq-header');
    header.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      
      // Close all other items
      faqItems.forEach(other => {
        other.classList.remove('active');
      });
      
      // Toggle current item
      if (!isActive) {
        item.classList.add('active');
      }
    });
  });
});

