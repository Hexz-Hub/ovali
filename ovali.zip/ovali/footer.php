<?php ?>
<!-- Footer -->
<footer id="contact">
    <div class="footer-content">
        <div class="footer-section">
            <h3>About Festival</h3>
            <p>The Ovaia Aguleri Festival celebrates our rich cultural heritage through music, dance, and traditional ceremonies.</p>
            <br>

            <div>
                <a href="https://twitter.com" target="_blank">
                    <i class="fa-brands fa-twitter"></i>
                </a>

                <a href="https://facebook.com" target="_blank">
                    <i class="fa-brands fa-facebook"></i>
                </a>

                <a href="https://instagram.com" target="_blank">
                    <i class="fa-brands fa-instagram"></i>
                </a>
                <a href="https://youtube.com" target="_blank">
                    <i class="fa-brands fa-youtube"></i>
                </a>
            </div>
        </div>
        <div class="footer-section">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="#highlights">Highlights</a></li>
                <li><a href="#news">News</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contact</h3>
            <ul>
                <li>Email: info@ovaiaaguleri.com</li>
                <li>Phone: +234 XXX XXX XXXX</li>
                <li>Location: Aguleri, Nigeria</li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Newsletter</h3>
            <p>Stay updated with festival news and events</p>
            <input type="email" placeholder="Your email" style="padding: 0.5rem; border-radius: 5px; border: 1px solid var(--border); background: var(--bg-primary); color: var(--text-primary); width: 100%; margin-top: 0.5rem;">
            <button class="btn" style="margin-top: 1rem; width: 100%;">Subscribe</button>
        </div>
    </div>
    <hr>
    <div class="footer-bottom">
        <p>&copy; 2024 Ovaia Aguleri Festival. All rights reserved.</p>
    </div>
</footer>

<script src="script.js"></script>
</body>

</html>