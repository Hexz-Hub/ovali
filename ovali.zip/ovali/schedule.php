<?php include 'nav.php'; ?>

<section class="schedule-hero">
    <h1>Festival <span>Schedule</span></h1>
    <p>
        Experience the magic of Ovaia Aguleri Festival with our carefully curated events.
        From traditional ceremonies to modern entertainment, there's something for everyone.
    </p>
</section>

<section class="schedule-section">
    <div class="schedule-container">

        <!-- Step 1 -->
        <div class="schedule-step">
            <div class="step-label">Step 1</div>
            <h3 class="step-title">Opening Ceremony</h3>
            <p class="step-meta">Date of Event</p>
            <p class="step-description">Join us for the grand opening ceremony featuring traditional welcome rites, cultural dances, and lighting of the festival flame.</p>
        </div>

        <!-- Step 2 -->
        <div class="schedule-step highlight">
            <div class="step-label highlight-label">Step 2</div>
            <h3 class="step-title highlight-title">Traditional Dance & Music Festival</h3>
            <p class="step-meta highlight-meta">Dec 26 - 27, 2024</p>
            <p class="step-description highlight-desc">Experience electrifying performances from local and international artists. From traditional Igbo dances to contemporary performances, this two-day extravaganza celebrates our cultural diversity.</p>
        </div>

        <!-- Step 3 -->
        <div class="schedule-step highlight">
            <div class="step-label highlight-label">Step 3</div>
            <h3 class="step-title highlight-title">Traditional Cuisine & Market</h3>
            <p class="step-meta highlight-meta">December 28, 2024</p>
            <p class="step-description highlight-desc">Taste authentic traditional dishes and explore local crafts. Local vendors showcase traditional cuisine and handmade artifacts celebrating our heritage.</p>
        </div>

        <!-- Step 4 -->
        <div class="schedule-step">
            <div class="step-label">Step 4</div>
            <h3 class="step-title">Royal Recognition</h3>
            <p class="step-meta">Date of Event</p>
            <p class="step-description">Witness the royal recognition ceremony honoring cultural custodians and community leaders who have preserved our traditions.</p>
        </div>

        <!-- Step 5 -->
        <div class="schedule-step highlight">
            <div class="step-label highlight-label">Step 5</div>
            <h3 class="step-title highlight-title">Grand Finale & Closing Ceremony</h3>
            <p class="step-meta highlight-meta">December 30 - 31, 2024</p>
            <p class="step-description highlight-desc">Join us for the spectacular grand finale with fireworks, live performances, and a night-long celebration marking the end of this memorable festival.</p>
        </div>

    </div>
</section>

<section class="important-section">
    <h2>Important Notes</h2>
    <div class="notes-grid">
        <div class="note-item">
            <h4>🎟️ Tickets</h4>
            <p>Most events are free. Premium seating for major events available at affordable rates.</p>
        </div>
        <div class="note-item">
            <h4>🚗 Parking</h4>
            <p>Free parking available at designated locations throughout the venue. Arrive early for convenient parking.</p>
        </div>
        <div class="note-item">
            <h4>🍽️ Food & Drinks</h4>
            <p>Multiple food vendors on-site serving traditional and contemporary cuisine.</p>
        </div>
        <div class="note-item">
            <h4>📱 Updates</h4>
            <p>Follow our social media for real-time updates and announcements during the festival.</p>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>