<?php if (!isset($GLOBALS['current_page'])) {
    $GLOBALS['current_page'] = basename($_SERVER['PHP_SELF']);
} ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>


<!-- Navigation -->
<header class="header">
    <div class="logo">
        <span class="logo-icon">O</span>
        <span>Ovala Aguleri</span>
    </div>

    <nav>
        <a href="index.php" class="<?php echo ($GLOBALS['current_page'] == 'index.php' && strpos($_SERVER['REQUEST_URI'], '#') === false) ? 'active' : ''; ?>">Home</a>
        <a href="about.php" class="<?php echo ($GLOBALS['current_page'] == 'about.php') ? 'active' : ''; ?>">About</a>
        <a href="schedule.php" class="<?php echo ($GLOBALS['current_page'] == 'schedule.php') ? 'active' : ''; ?>">Schedule</a>
        <a href="gallery.php" class="<?php echo ($GLOBALS['current_page'] == 'gallery.php') ? 'active' : ''; ?>">Gallery</a>
        <a href="contact.php" class="<?php echo ($GLOBALS['current_page'] == 'contact.php') ? 'active' : ''; ?>">Contact</a>
    </nav>

    <button id="themeToggle" class="theme-btn">🌙</button>
</header>

</body>
</html>