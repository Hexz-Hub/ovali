<?php
$basePath = dirname(__FILE__);
$GLOBALS['current_page'] = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gallery | Ovala Aguleri Festival</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;800&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css" />
    <style>
        /* Gallery Page Specific Styles */
        .gallery-hero {
            background: linear-gradient(135deg, rgba(255, 159, 26, 0.1), rgba(255, 159, 26, 0.05));
            padding: 80px 60px;
            text-align: center;
            border-bottom: 2px solid var(--accent);
        }

        .gallery-hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: 3.5rem;
            margin-bottom: 20px;
            font-weight: 800;
        }

        .gallery-hero h1 span {
            color: var(--accent);
        }

        .gallery-hero .subtitle {
            font-size: 1rem;
            color: var(--muted);
            max-width: 700px;
            margin: 0 auto;
            line-height: 1.6;
        }

        /* Main Gallery Grid Section */
        .gallery-section {
            padding: 80px 60px;
            background: rgba(255, 159, 26, 0.02);
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .gallery-item {
            position: relative;
            overflow: hidden;
            border-radius: 8px;
            aspect-ratio: 1;
            background: rgba(255, 159, 26, 0.1);
            border: 2px solid rgba(255, 159, 26, 0.2);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .gallery-item:hover {
            border-color: var(--accent);
            transform: scale(1.02);
            box-shadow: 0 10px 30px rgba(255, 159, 26, 0.2);
        }

        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .gallery-item:hover img {
            transform: scale(1.05);
        }

        .gallery-item.placeholder {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: var(--accent);
        }

        .gallery-item-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 159, 26, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .gallery-item:hover .gallery-item-overlay {
            opacity: 1;
        }

        .gallery-item-overlay-icon {
            font-size: 2.5rem;
            color: var(--text);
        }

        /* Highlights Section */
        .highlights-section {
            padding: 80px 60px;
            background: transparent;
        }

        .highlights-section h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            text-align: center;
            margin-bottom: 15px;
        }

        .highlights-section h2 span {
            color: var(--accent);
        }

        .highlights-subtitle {
            text-align: center;
            color: var(--muted);
            margin-bottom: 60px;
            font-size: 0.95rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }

        .highlights-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 30px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .highlight-card {
            background: rgba(255, 159, 26, 0.08);
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid rgba(255, 159, 26, 0.2);
            transition: all 0.3s ease;
        }

        .highlight-card:hover {
            background: rgba(255, 159, 26, 0.12);
            transform: translateY(-5px);
            border-color: var(--accent);
            box-shadow: 0 10px 30px rgba(255, 159, 26, 0.2);
        }

        .highlight-image {
            width: 100%;
            aspect-ratio: 1;
            background: rgba(255, 159, 26, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            overflow: hidden;
        }

        .highlight-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .highlight-content {
            padding: 25px;
        }

        .highlight-content h3 {
            color: var(--accent);
            font-size: 1.2rem;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .highlight-content p {
            color: var(--muted);
            font-size: 0.9rem;
            line-height: 1.6;
        }

        /* Image Categories Section */
        .categories-section {
            padding: 80px 60px;
            background: rgba(255, 159, 26, 0.02);
        }

        .categories-section h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin-bottom: 50px;
            text-align: center;
        }

        .categories-section h2 span {
            color: var(--accent);
        }

        .categories-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 40px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .category-card {
            background: rgba(255, 159, 26, 0.08);
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid rgba(255, 159, 26, 0.2);
            transition: all 0.3s ease;
        }

        .category-card:hover {
            border-color: var(--accent);
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(255, 159, 26, 0.2);
        }

        .category-image {
            width: 100%;
            aspect-ratio: 16/9;
            background: rgba(255, 159, 26, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            overflow: hidden;
        }

        .category-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .category-content {
            padding: 30px;
        }

        .category-content h3 {
            color: var(--accent);
            font-size: 1.3rem;
            margin-bottom: 12px;
            font-weight: 600;
        }

        .category-content p {
            color: var(--muted);
            font-size: 0.95rem;
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .category-content .btn-small {
            color: var(--accent);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .category-content .btn-small:hover {
            color: var(--text);
            transform: translateX(5px);
        }

        /* Masonry Layout for Featured Images */
        .featured-gallery-section {
            padding: 80px 60px;
            background: transparent;
        }

        .featured-gallery-section h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            text-align: center;
            margin-bottom: 15px;
        }

        .featured-gallery-section h2 span {
            color: var(--accent);
        }

        .featured-subtitle {
            text-align: center;
            color: var(--muted);
            margin-bottom: 50px;
            font-size: 0.95rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }

        .masonry-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .masonry-item {
            position: relative;
            overflow: hidden;
            border-radius: 8px;
            background: rgba(255, 159, 26, 0.1);
            border: 2px solid rgba(255, 159, 26, 0.2);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .masonry-item:nth-child(2),
        .masonry-item:nth-child(5) {
            grid-column: span 2;
        }

        .masonry-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .masonry-item:hover img {
            transform: scale(1.05);
        }

        .masonry-item:hover {
            border-color: var(--accent);
            box-shadow: 0 10px 30px rgba(255, 159, 26, 0.2);
        }

        /* Stats Section */
        .stats-section {
            padding: 80px 60px;
            background: rgba(255, 159, 26, 0.02);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 30px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .stat-card {
            background: rgba(255, 159, 26, 0.08);
            padding: 40px 25px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid rgba(255, 159, 26, 0.2);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            background: rgba(255, 159, 26, 0.12);
            transform: translateY(-5px);
            border-color: var(--accent);
        }

        .stat-icon {
            font-size: 2.5rem;
            color: var(--accent);
            margin-bottom: 15px;
        }

        .stat-number {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            color: var(--accent);
            font-weight: 800;
            margin-bottom: 8px;
        }

        .stat-label {
            color: var(--muted);
            font-weight: 600;
            font-size: 0.9rem;
        }

        /* Call to Action */
        .gallery-cta {
            padding: 80px 60px;
            background: linear-gradient(135deg, rgba(255, 159, 26, 0.1), rgba(255, 159, 26, 0.05));
            text-align: center;
            border-top: 2px solid var(--accent);
        }

        .gallery-cta h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin-bottom: 20px;
        }

        .gallery-cta h2 span {
            color: var(--accent);
        }

        .gallery-cta p {
            color: var(--muted);
            font-size: 1.1rem;
            margin-bottom: 30px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }

        .gallery-cta-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .gallery-hero {
                padding: 50px 20px;
            }

            .gallery-hero h1 {
                font-size: 2.5rem;
            }

            .gallery-section {
                padding: 50px 20px;
            }

            .gallery-grid {
                grid-template-columns: 1fr;
            }

            .highlights-grid {
                grid-template-columns: 1fr;
            }

            .categories-grid {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .masonry-item:nth-child(2),
            .masonry-item:nth-child(5) {
                grid-column: span 1;
            }

            .gallery-cta {
                padding: 50px 20px;
            }

            .gallery-cta-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
    <?php include 'nav.php'; ?>

    <!-- Gallery Hero Section -->
    <section class="gallery-hero">
        <h1>Festival <span>Gallery</span></h1>
        <p class="subtitle">
            Explore the vibrant celebrations, sacred ceremonies, and breathtaking moments from the Ovala Aguleri Festival.
            Each image tells a story of cultural pride, ancestral connection, and community celebration.
        </p>
    </section>

    <!-- Main Gallery Grid -->
    <section class="gallery-section">
        <div class="gallery-grid">
            <div class="gallery-item placeholder">
                <img src="assets/festival1.jpg" alt="Masquerade Performance">
            </div>
            <div class="gallery-item placeholder">
                <img src="assets/festival2.jpg" alt="Royal Ceremony">
            </div>
            <div class="gallery-item placeholder">
                <img src="assets/festival3.jpg" alt="Cultural Dance">
            </div>
            <div class="gallery-item placeholder">
                <img src="assets/festival4.jpg" alt="Traditional Attire">
            </div>
            <div class="gallery-item placeholder">
                <img src="assets/festival5.jpg" alt="Drumming Performance">
            </div>
            <div class="gallery-item placeholder">
                <img src="assets/festival6.jpg" alt="Crowd Celebration">
            </div>
            <div class="gallery-item placeholder">
                <img src="assets/festival7.jpg" alt="Masquerade Procession">
            </div>
            <div class="gallery-item placeholder">
                <img src="assets/festival8.jpg" alt="Ritual Ceremony">
            </div>
            <div class="gallery-item placeholder">
                <img src="assets/festival9.jpg" alt="Festival Highlights">
            </div>
        </div>
    </section>

    <!-- Festival Highlights Section -->
    <section class="highlights-section">
        <h2>Festival <span>Highlights</span></h2>
        <p class="highlights-subtitle">
            Captured moments from our most memorable festival days, showcasing the energy, artistry, and cultural significance
            that make Ovala Aguleri a celebration like no other.
        </p>
        <div class="highlights-grid">
            <div class="highlight-card">
                <div class="highlight-image">🎭</div>
                <div class="highlight-content">
                    <h3>Opening Ceremony</h3>
                    <p>
                        The grand opening features sacred ceremonies, ancestral invocations, and the official declaration
                        of the festival by traditional rulers.
                    </p>
                </div>
            </div>
            <div class="highlight-card">
                <div class="highlight-image">🎪</div>
                <div class="highlight-content">
                    <h3>Masquerade Parade</h3>
                    <p>
                        Stunning masquerade displays with elaborate costumes, intricate choreography, and centuries-old
                        artistic traditions on full display.
                    </p>
                </div>
            </div>
            <div class="highlight-card">
                <div class="highlight-image">🎵</div>
                <div class="highlight-content">
                    <h3>Musical Performances</h3>
                    <p>
                        Traditional drummers, vocal performances, and contemporary musicians create an electrifying atmosphere
                        that celebrates both heritage and modernity.
                    </p>
                </div>
            </div>
            <div class="highlight-card">
                <div class="highlight-image">🎨</div>
                <div class="highlight-content">
                    <h3>Art & Craft Exhibition</h3>
                    <p>
                        Local artisans showcase traditional crafts, sculptures, textiles, and artwork representing generations
                        of accumulated skill and aesthetic mastery.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Image Categories Section -->
    <section class="categories-section">
        <h2>Gallery <span>Categories</span></h2>
        <div class="categories-grid">
            <div class="category-card">
                <div class="category-image">🎭</div>
                <div class="category-content">
                    <h3>Masquerades & Costumes</h3>
                    <p>
                        Explore the intricate designs, vibrant colors, and stunning masquerade performances that showcase
                        centuries of artistic tradition and cultural significance. Each mask tells a unique story of Aguleri heritage.
                    </p>
                    <a href="#" class="btn-small">View Category <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="category-card">
                <div class="category-image">🎵</div>
                <div class="category-content">
                    <h3>Music & Dance</h3>
                    <p>
                        Rhythmic drumming, energetic dance performances, and musical celebrations that bring the festival
                        to life. Experience the pulse and soul of Aguleri culture through movement and sound.
                    </p>
                    <a href="#" class="btn-small">View Category <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="category-card">
                <div class="category-image">🎨</div>
                <div class="category-content">
                    <h3>Art & Craftsmanship</h3>
                    <p>
                        Traditional artworks, sculptures, textiles, and handcrafted items created by local artisans. Each
                        piece represents generations of skill, creativity, and cultural knowledge passed down through families.
                    </p>
                    <a href="#" class="btn-small">View Category <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Gallery Section -->
    <section class="featured-gallery-section">
        <h2>Featured <span>Moments</span></h2>
        <p class="featured-subtitle">
            A curated collection of the most iconic and memorable moments from recent festival celebrations,
            capturing the spirit of unity, pride, and cultural excellence.
        </p>
        <div class="masonry-gallery">
            <div class="masonry-item placeholder">
                <img src="assets/featured1.jpg" alt="Featured Moment 1">
                <div class="gallery-item-overlay">
                    <div class="gallery-item-overlay-icon">
                        <i class="fas fa-search-plus"></i>
                    </div>
                </div>
            </div>
            <div class="masonry-item placeholder">
                <img src="assets/featured2.jpg" alt="Featured Moment 2">
                <div class="gallery-item-overlay">
                    <div class="gallery-item-overlay-icon">
                        <i class="fas fa-search-plus"></i>
                    </div>
                </div>
            </div>
            <div class="masonry-item placeholder">
                <img src="assets/featured3.jpg" alt="Featured Moment 3">
                <div class="gallery-item-overlay">
                    <div class="gallery-item-overlay-icon">
                        <i class="fas fa-search-plus"></i>
                    </div>
                </div>
            </div>
            <div class="masonry-item placeholder">
                <img src="assets/featured4.jpg" alt="Featured Moment 4">
                <div class="gallery-item-overlay">
                    <div class="gallery-item-overlay-icon">
                        <i class="fas fa-search-plus"></i>
                    </div>
                </div>
            </div>
            <div class="masonry-item placeholder">
                <img src="assets/featured5.jpg" alt="Featured Moment 5">
                <div class="gallery-item-overlay">
                    <div class="gallery-item-overlay-icon">
                        <i class="fas fa-search-plus"></i>
                    </div>
                </div>
            </div>
            <div class="masonry-item placeholder">
                <img src="assets/featured6.jpg" alt="Featured Moment 6">
                <div class="gallery-item-overlay">
                    <div class="gallery-item-overlay-icon">
                        <i class="fas fa-search-plus"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Statistics -->
    <section class="stats-section">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📸</div>
                <div class="stat-number">500+</div>
                <div class="stat-label">Festival Images</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🎭</div>
                <div class="stat-number">100+</div>
                <div class="stat-label">Cultural Groups</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-number">50K+</div>
                <div class="stat-label">Participants</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🌍</div>
                <div class="stat-number">10</div>
                <div class="stat-label">Festival Days</div>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="gallery-cta">
        <h2>Share Your <span>Moments</span></h2>
        <p>
            Have photos or videos from the Ovala Aguleri Festival? We'd love to feature your moments in our gallery.
            Connect with us to submit your contributions and be part of our growing collection of festival memories.
        </p>
        <div class="gallery-cta-buttons">
            <a href="contact.php" class="btn primary">Submit Your Photos</a>
            <a href="#" class="btn outline">Follow Our Social Media</a>
        </div>
    </section>

    <?php include 'footer.php'; ?>

    <script src="script.js"></script>
</body>

</html>