<?php include 'nav.php'; ?>

<section class="contact-hero">
    <h1>Contact Us</h1>
    <p>
        Have questions about the festival? Want to become a sponsor or partner? We'd love to hear from you. Get in touch with us today!
    </p>
</section>

<section class="contact-section container">

    <div class="contact-grid">

        <!-- LEFT FORM -->
        <div class="contact-form">
            <h3>Send us a <span>Message</span></h3>

            <form>
                <div class="form-row">
                    <input type="text" placeholder="Your Name" required>
                    <input type="email" placeholder="Email Address" required>
                </div>

                <input type="text" placeholder="Subject" required>

                <textarea placeholder="Tell us more about your inquiry..." required></textarea>

                <button type="submit" class="btn primary">
                    <span>📨</span> Send Message
                </button>
            </form>
        </div>

        <!-- RIGHT INFO -->
        <div class="contact-info">
            <h3>Get in <span>Touch</span></h3>

            <div class="info-box">
                <div class="info-icon">📍</div>
                <div class="info-content">
                    <h4>Location</h4>
                    <p>Aguleri, Anambra East LGA<br>Anambra State, Nigeria</p>
                </div>
            </div>

            <div class="info-box">
                <div class="info-icon">📞</div>
                <div class="info-content">
                    <h4>Phone</h4>
                    <p>+234 800 000 0000<br>+234 900 000 0000</p>
                </div>
            </div>

            <div class="info-box">
                <div class="info-icon">✉</div>
                <div class="info-content">
                    <h4>Email</h4>
                    <p>info@ovaiaaguleri.com<br>support@ovaiaaguleri.com</p>
                </div>
            </div>

        </div>
    </div>

</section>

<section class="faq-section container">
    <h2>Frequently Asked <span>Questions</span></h2>

    <div class="faq-container">
        <div class="faq-item">
            <div class="faq-header">
                <h4>When is the Ovala Aguleri Festival?</h4>
                <span class="faq-toggle">+</span>
            </div>
            <div class="faq-body">
                <p>The festival is held annually from December 27th to January 5th. This year marks the 126th edition of this celebrated cultural event.</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-header">
                <h4>Is there an entrance fee?</h4>
                <span class="faq-toggle">+</span>
            </div>
            <div class="faq-body">
                <p>Most events are completely free and open to the public. Some premium seating for major events may require registration, but all core festival activities are free.</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-header">
                <h4>Where can I find accommodation?</h4>
                <span class="faq-toggle">+</span>
            </div>
            <div class="faq-body">
                <p>We have partnered with local hotels and guesthouses in Aguleri to provide comfortable accommodation for our guests. Contact us for a list of recommended places to stay.</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-header">
                <h4>How can I become a sponsor?</h4>
                <span class="faq-toggle">+</span>
            </div>
            <div class="faq-body">
                <p>We welcome corporate sponsors and partners. Please reach out to us via email at info@ovaiaaguleri.com or call our office to discuss sponsorship opportunities.</p>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>